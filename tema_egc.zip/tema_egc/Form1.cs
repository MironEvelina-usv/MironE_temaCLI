﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

using OpenTK.Graphics.OpenGL;

using OpenTK3_StandardTemplate_WinForms.helpers;
using OpenTK3_StandardTemplate_WinForms.objects;

namespace OpenTK3_StandardTemplate_WinForms
{
    public partial class MainForm : Form
    {
        private Axes mainAxis;
        private Rectangles rectangles;
        private Camera cam;
        private Scene scene;
        //###################
        private Cub cub;


        //************
        private bool enableLighting = false;
        private float[] lightPosition = { 1.0f, 1.0f, 1.0f, 0.0f }; // Pozitia sursei de lumina
        private float[] lightAmbient = { 0.2f, 0.2f, 0.2f, 1.0f }; // Componenta ambientala
        private float[] lightDiffuse = { 1.0f, 1.0f, 1.0f, 1.0f }; // Componenta difuza
        private float[] lightSpecular = { 1.0f, 1.0f, 1.0f, 1.0f }; // Componenta speculara
        private float[] materialAmbient = { 0.2f, 0.2f, 0.2f, 1.0f }; // Reflectanta ambientala a materialului
        private float[] materialDiffuse = { 1.0f, 0.8f, 0.0f, 1.0f }; // Reflectanta difuza a materialului
        private float[] materialSpecular = { 1.0f, 1.0f, 1.0f, 1.0f }; // Reflectanta speculara a materialului
        private float materialShininess = 100.0f; // Coeficientul shininess pentru material



        private Point mousePosition;

        public MainForm()
        {
            // general init
            InitializeComponent();

            // init VIEWPORT
            scene = new Scene();

            scene.GetViewport().Load += new EventHandler(this.mainViewport_Load);
            scene.GetViewport().Paint += new PaintEventHandler(this.mainViewport_Paint);
            scene.GetViewport().MouseMove += new MouseEventHandler(this.mainViewport_MouseMove);

            this.Controls.Add(scene.GetViewport());
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // init RNG
            Randomizer.Init();

            //###################
            cub = new Cub();
            //###################
            // init CAMERA/EYE
            cam = new Camera(scene.GetViewport());

            // init AXES
            mainAxis = new Axes(showAxes.Checked);
            rectangles = new Rectangles();
            this.Text = "test";
        }

        private void showAxes_CheckedChanged(object sender, EventArgs e)
        {
            mainAxis.SetVisibility(showAxes.Checked);

            scene.Invalidate();
        }

        private void changeBackground_Click(object sender, EventArgs e)
        {
            GL.ClearColor(Randomizer.GetRandomColor());

            scene.Invalidate();
        }

        private void resetScene_Click(object sender, EventArgs e)
        {
            showAxes.Checked = true;
            mainAxis.SetVisibility(showAxes.Checked);
            cub.SetVisibility(false);
            scene.Reset();
            cam.Reset();

            scene.Invalidate();
        }

        private void mainViewport_Load(object sender, EventArgs e)
        {
            scene.Reset();
        }

        private void mainViewport_MouseMove(object sender, MouseEventArgs e)
        {
            mousePosition = new Point(e.X, e.Y);
            scene.Invalidate();
        }

        private void mainViewport_Paint(object sender, PaintEventArgs e)
        {
            GL.Clear(ClearBufferMask.ColorBufferBit);
            GL.Clear(ClearBufferMask.DepthBufferBit);

            cam.SetView();

            if (enableRotation.Checked == true)
            {
                // Doar după axa Ox.
                GL.Rotate(Math.Max(mousePosition.X, mousePosition.Y), 1, 1, 1);
            }

            // GRAPHICS PAYLOAD
            mainAxis.Draw();

            if (enableObjectRotation.Checked == true)
            {
                // Rotatie a obiectului
                GL.PushMatrix();
                GL.Rotate(Math.Max(mousePosition.X, mousePosition.Y), 1, 1, 1);
                rectangles.Draw();

                //###################
                cub.Draw();
                //###################
                GL.Enable(EnableCap.Texture2D);

                GL.PopMatrix();
            }
            else
            {
                rectangles.Draw();
                cub.Draw();
            }
            scene.Invalidate();
            scene.GetViewport().SwapBuffers();
        }
        //###################
        private void afiseazaCub_Click(object sender, EventArgs e)
        {
            cub.ToggleVisibility();
        }

        //**********
        private void Iluminare_Click(object sender, EventArgs e)
        {
            enableLighting = !enableLighting;

            if (enableLighting)
            {
                GL.Enable(EnableCap.Lighting);
                GL.Enable(EnableCap.Light0);
                GL.Light(LightName.Light0, LightParameter.Position, lightPosition);
                GL.Light(LightName.Light0, LightParameter.Ambient, lightAmbient);
                GL.Light(LightName.Light0, LightParameter.Diffuse, lightDiffuse);
                GL.Light(LightName.Light0, LightParameter.Specular, lightSpecular);
            }
            else
            {
                GL.Disable(EnableCap.Lighting);
            }

            scene.Invalidate();
        }


        private void Textura_Click(object sender, EventArgs e)
        {
            string caleTextura = "/bin/wallpaper.jpg";

            // Încarcă imaginea într-un obiect Bitmap
            Bitmap texturaBitmap = new Bitmap(caleTextura);

            if (texturaBitmap == null)
            {
                MessageBox.Show("Imaginea nu a putut fi încărcată.");
                return;
            }

            // Generare și legare textură OpenGL
            int idTextura;
            GL.GenTextures(1, out idTextura);
            GL.BindTexture(TextureTarget.Texture2D, idTextura);

            // Setează parametrii de textură (poate fi adaptat în funcție de necesități)
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);

            // Încarcă imaginea în textură
            BitmapData data = texturaBitmap.LockBits(new Rectangle(0, 0, texturaBitmap.Width, texturaBitmap.Height),
                                                      ImageLockMode.ReadOnly,
                                                      System.Drawing.Imaging.PixelFormat.Format32bppArgb);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, data.Width, data.Height, 0,
                          OpenTK.Graphics.OpenGL.PixelFormat.Bgra, PixelType.UnsignedByte, data.Scan0);
            texturaBitmap.UnlockBits(data);

            // Aplică textura pe fața cubului
            GL.Enable(EnableCap.Texture2D);
            GL.TexEnv(TextureEnvTarget.TextureEnv, TextureEnvParameter.TextureEnvMode, (int)TextureEnvMode.Modulate);

            // Activează lumina dacă este activată
            if (enableLighting)
            {
                GL.Enable(EnableCap.Lighting);
                GL.Enable(EnableCap.Light0);
                GL.Light(LightName.Light0, LightParameter.Position, lightPosition);
                GL.Light(LightName.Light0, LightParameter.Ambient, lightAmbient);
                GL.Light(LightName.Light0, LightParameter.Diffuse, lightDiffuse);
                GL.Light(LightName.Light0, LightParameter.Specular, lightSpecular);

                // Configurare material
                GL.Material(MaterialFace.FrontAndBack, MaterialParameter.Ambient, materialAmbient);
                GL.Material(MaterialFace.FrontAndBack, MaterialParameter.Diffuse, materialDiffuse);
                GL.Material(MaterialFace.FrontAndBack, MaterialParameter.Specular, materialSpecular);
                GL.Material(MaterialFace.FrontAndBack, MaterialParameter.Shininess, materialShininess);
            }

            // Desenează cubul cu textură
            GL.PushMatrix();
            GL.Translate(0.0f, 0.0f, -5.0f); // Ajustează poziția cubului în funcție de nevoie

            cub.DrawTextured(); // Noua funcție pentru a desena cubul cu textură

            GL.PopMatrix();

            // Dezactivează textura și lumina
            GL.Disable(EnableCap.Texture2D);
            GL.Disable(EnableCap.Lighting);

            // La final, nu uita să eliberezi textura când nu mai ai nevoie de ea
            GL.DeleteTextures(1, ref idTextura);

            scene.Invalidate();
        }
    }
}
