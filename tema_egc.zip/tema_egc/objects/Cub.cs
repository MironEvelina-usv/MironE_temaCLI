﻿

using OpenTK.Graphics.OpenGL;

using OpenTK3_StandardTemplate_WinForms.helpers;

using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenTK3_StandardTemplate_WinForms.objects
{
    internal class Cub
    {
        private float[] textureCoordinates =
    {
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        0.0f, 1.0f
    };

        private bool visibility;
        private int[ , ] objVertices ={{25, 50, 25,
                                      50, 25, 50,
                                      25, 50, 25,
                                      50, 25, 50,
                                      25, 25, 25,
                                      25, 25, 25,
                                      25, 50, 25,
                                      50, 50, 25,
                                      50, 50, 50,
                                      50, 50, 50,
                                      25, 50, 25,
                                      50, 50, 25},
                                     {25, 25, 60,
                                      25, 60, 60,
                                      25, 25, 25,
                                      25, 25, 25,
                                      25, 60, 25,
                                      60, 25, 60,
                                      60, 60, 60,
                                      60, 60, 60,
                                      25, 60, 25,
                                      60, 25, 60,
                                      25, 25, 60,
                                      25, 60, 60},
                                     {30, 30, 30,
                                      30, 30, 30,
                                      30, 30, 60,
                                      30, 60, 60,
                                      30, 30, 60,
                                      30, 60, 60,
                                      30, 30, 60,
                                      30, 60, 60,
                                      30, 30, 60,
                                      30, 60, 60,
                                      60, 60, 60,
                                      60, 60, 60}};
        private Color[] colorVertices = { Color.White, Color.LawnGreen, Color.WhiteSmoke, Color.Tomato, Color.Turquoise, Color.OldLace, Color.Olive, Color.MidnightBlue, Color.PowderBlue, Color.PeachPuff, Color.LavenderBlush, Color.MediumAquamarine };
        private ArrayList colors;
        private PolygonMode currentPolygonState = PolygonMode.Fill;

       

        public Cub()
        {
            colors = new ArrayList();
            for (int i = 0; i < 4;i++)
            {
                colors.Add(Randomizer.GetRandomColor());
            }
            visibility = true;
        }


        public bool GetVisibility()
        {
            return visibility;
        }

        public void SetVisibility(bool _visibility)
        {
            visibility = _visibility;
        }

        public void Show()
        {
            visibility = true;
        }

        public void Hide()
        {
            visibility = false;
        }

        public void ToggleVisibility()
        {
            visibility = !visibility;
        }

        public void PolygonDrawingStyle(String style)
        {
            if (style == "line")
            {
                currentPolygonState = PolygonMode.Line;
                return;
            }

            if (style == "surface")
            {
                currentPolygonState = PolygonMode.Fill;
                return;
            }

        }

        public void DrawTextured()
        {
            if (!visibility) return;

            GL.Begin(PrimitiveType.Triangles);
            for (int i = 0; i < 36; i += 3)
            {
                GL.Color3(colorVertices[i / 3]);

                // Setează coordonatele texturii
                GL.TexCoord2(textureCoordinates[i], textureCoordinates[i + 1]);
                GL.Vertex3(objVertices[0, i], objVertices[1, i], objVertices[2, i]);

                GL.TexCoord2(textureCoordinates[i + 2], textureCoordinates[i + 3]);
                GL.Vertex3(objVertices[0, i + 1], objVertices[1, i + 1], objVertices[2, i + 1]);

                GL.TexCoord2(textureCoordinates[i + 4], textureCoordinates[i + 5]);
                GL.Vertex3(objVertices[0, i + 2], objVertices[1, i + 2], objVertices[2, i + 2]);
            }
            GL.End();
        }
        public void Draw()
        {

            if (!visibility) return;

            GL.Begin(PrimitiveType.Triangles);
            for (int i = 0; i < 35; i += 3)
            {
                GL.Color3(colorVertices[i / 3]);
                GL.Vertex3(objVertices[0, i ], objVertices[1, i], objVertices[2, i]);
                GL.Vertex3(objVertices[0, i + 1], objVertices[1, i + 1], objVertices[2, i + 1]);
                GL.Vertex3(objVertices[0, i +2], objVertices[1, i + 2], objVertices[2, i  +2]);
            }
            GL.End();
        }

    }
}
